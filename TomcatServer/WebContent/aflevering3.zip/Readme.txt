Navne - Studienumre:

Markus Andreassen - 201304194
Daniel Graungaard - 201304191
Salban Karuvalthamby - 201304214
Simon Alexander Alsing - 201301202


Hold:

IT1


Placering:

http://llama13.cs.au.dk:1729/webshop


Hvad virker?

Alt hvad der skal


Hvad virker ikke?

Intet, så vidt vi ved



